# Copyright (c) 2024, Your Company and contributors
# For license information, please see license.txt

import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import now_datetime
from frappe.utils.password import get_decrypted_password


class NFCompanySettings(Document):
    def get_certificate_password(self):
        """Get the decrypted certificate password."""
        if not self.name or self.is_new():
            # During creation, password is in plain text
            return self.certificate_password

        # For saved documents, decrypt the password
        return get_decrypted_password(
            "NF Company Settings",
            self.name,
            "certificate_password"
        )
    def validate(self):
        """Validate company settings."""
        self.validate_cnpj()
        self.validate_certificate()

    def validate_cnpj(self):
        """Validate CNPJ format."""
        if self.cnpj:
            from brazil_nf.utils.cnpj import validate_cnpj, clean_cnpj

            cleaned = clean_cnpj(self.cnpj)
            if len(cleaned) != 14:
                frappe.throw(
                    _("CNPJ must be 14 digits"),
                    title=_("Validation Error")
                )

            if not validate_cnpj(cleaned):
                frappe.msgprint(
                    _("Warning: CNPJ may be invalid. Please verify."),
                    indicator="orange",
                    alert=True
                )

            # Store cleaned version
            self.cnpj = cleaned

    def validate_certificate(self):
        """Validate the uploaded certificate."""
        # If no certificate file, clear all certificate-related fields
        if not self.certificate_file:
            self.certificate_valid = 0
            self.certificate_expiry = None
            self.certificate_password = ""
            return

        # If certificate file exists but no password, mark as invalid
        if not self.certificate_password:
            self.certificate_valid = 0
            self.certificate_expiry = None
            return

        # If certificate is already validated and we're not changing the password,
        # skip re-validation to avoid issues with encrypted password
        if self.certificate_valid and not self.has_value_changed("certificate_password") and not self.has_value_changed("certificate_file"):
            return

        # Get the password - during save it's plain text, otherwise decrypt
        password = self.certificate_password
        if not self.is_new() and self.name:
            # Check if password was just changed (will be plain text) or is from DB (encrypted)
            if not self.has_value_changed("certificate_password"):
                password = self.get_certificate_password()

        # Try to validate the certificate
        try:
            from brazil_nf.services.cert_utils import validate_pfx_certificate

            expiry = validate_pfx_certificate(
                self.certificate_file,
                password
            )

            self.certificate_expiry = expiry
            self.certificate_valid = 1

            frappe.msgprint(
                _("Certificate validated successfully. Expires on {0}").format(expiry),
                indicator="green",
                alert=True
            )

        except Exception as e:
            self.certificate_valid = 0
            self.certificate_expiry = None
            frappe.msgprint(
                _("Certificate validation failed: {0}").format(str(e)),
                indicator="red",
                alert=True
            )

    @frappe.whitelist()
    def test_connection(self):
        """Test connection to SEFAZ using this company's certificate."""
        if not self.certificate_valid:
            frappe.throw(_("Certificate is not valid. Please upload a valid certificate."))

        try:
            from brazil_nf.services.dfe_client import test_sefaz_connection

            result = test_sefaz_connection(self.name)
            return result
        except Exception as e:
            frappe.throw(_("Connection test failed: {0}").format(str(e)))

    @frappe.whitelist()
    def fetch_now(self, document_type=None):
        """Manually trigger fetch for this company."""
        from brazil_nf.services.dfe_client import fetch_documents_for_company

        result = fetch_documents_for_company(self.name, document_type)
        self.last_sync = now_datetime()
        self.save()

        return result

    def update_last_nsu(self, document_type, nsu):
        """Update the last NSU for a document type using direct DB update to avoid conflicts."""
        field_map = {
            "NF-e": "last_nsu_nfe",
            "CT-e": "last_nsu_cte",
            "NFS-e": "last_nsu_nfse"
        }

        field = field_map.get(document_type)
        if field and nsu:
            nsu_str = str(nsu)
            sync_time = now_datetime()

            frappe.logger().info(f"Updating {field} from {getattr(self, field, '0')} to {nsu_str}")

            # Use direct DB update to avoid document modification conflicts
            frappe.db.set_value(
                "NF Company Settings",
                self.name,
                {
                    field: nsu_str,
                    "last_sync": sync_time
                },
                update_modified=False
            )

            # Commit immediately to ensure persistence
            frappe.db.commit()

            # Update local attributes for consistency
            setattr(self, field, nsu_str)
            self.last_sync = sync_time

            frappe.logger().info(f"NSU updated successfully: {field} = {nsu_str}")

    def get_last_nsu(self, document_type):
        """Get the last NSU for a document type."""
        field_map = {
            "NF-e": "last_nsu_nfe",
            "CT-e": "last_nsu_cte",
            "NFS-e": "last_nsu_nfse"
        }

        field = field_map.get(document_type)
        if field:
            return getattr(self, field, "0") or "0"

        return "0"


def get_company_settings(company):
    """Get NF Company Settings for a company."""
    if frappe.db.exists("NF Company Settings", company):
        return frappe.get_doc("NF Company Settings", company)
    return None


def get_all_enabled_companies():
    """Get all companies with sync enabled."""
    return frappe.get_all(
        "NF Company Settings",
        filters={"sync_enabled": 1, "certificate_valid": 1},
        fields=["name", "company", "cnpj"]
    )


@frappe.whitelist()
def test_connection(company_settings_name):
    """
    Test connection to SEFAZ using company's certificate.

    Args:
        company_settings_name: Name of NF Company Settings document

    Returns:
        dict: Test result with success flag and message
    """
    doc = frappe.get_doc("NF Company Settings", company_settings_name)

    if not doc.certificate_valid:
        return {
            "success": False,
            "message": _("Certificate is not valid. Please upload a valid certificate and save.")
        }

    if not doc.certificate_file:
        return {
            "success": False,
            "message": _("No certificate file uploaded.")
        }

    try:
        from brazil_nf.services.dfe_client import test_sefaz_connection
        result = test_sefaz_connection(company_settings_name)

        return {
            "success": result.get("status") == "success",
            "message": result.get("message", _("Connection test completed"))
        }
    except Exception as e:
        frappe.log_error(str(e), "SEFAZ Connection Test Error")
        return {
            "success": False,
            "message": _("Connection test failed: {0}").format(str(e))
        }


@frappe.whitelist()
def fetch_documents(company_settings_name, document_type=None):
    """
    Fetch documents from SEFAZ for a company.

    Args:
        company_settings_name: Name of NF Company Settings document
        document_type: Optional specific document type (NF-e, CT-e, NFS-e)

    Returns:
        dict: Fetch results
    """
    doc = frappe.get_doc("NF Company Settings", company_settings_name)

    if not doc.certificate_valid:
        frappe.throw(_("Certificate is not valid. Please upload a valid certificate."))

    try:
        from brazil_nf.services.dfe_client import fetch_documents_for_company

        result = fetch_documents_for_company(company_settings_name, document_type)

        # Update last sync time
        doc.last_sync = now_datetime()
        doc.save(ignore_permissions=True)

        return result
    except Exception as e:
        frappe.log_error(str(e), "SEFAZ Fetch Error")
        frappe.throw(_("Fetch failed: {0}").format(str(e)))
